<?php
	$filepath=realpath(dirname(__FILE__)); 
	include_once ($filepath.'/../lib/database.php');
	include_once ($filepath.'/../helpers/format.php');
?>



<?php


class Category{

	private $db;
	private $fm;
	
	public function __construct()
	{
		$this->db=new Database();
		$this->fm=new Format();
		
}

	public function catInsert($catName){
		$catName=$this->fm->validation($catName);
		$catName=mysqli_real_escape_string($this->db->link,$catName);

		if(empty($catName)){
			$msg="<span style='font-size: 18px; color: red;'> Categoy field can't be empty can't be empty</span>";
			return $msg;
		}else{
			$query="INSERT INTO category_table(catName) VALUES('$catName')";
			$catInsert=$this->db->insert($query);
			if($catInsert){
				$msg="<span style='font-size: 18px; color: green;'>Category inserted successfully</span>";
				return $msg;
			}else{
				$msg="<span style='font-size: 18px; color: red;'>Category wasn't inserted..</span>";
				return $msg;

			}


		}

	}


	public function getAllCat($value='')
	{
		$query='SELECT * FROM category_table ORDER BY catId asc';
		$result=$this->db->select($query);
		return $result;
	}

	public function getCatById($id){
		$query="SELECT * FROM category_table WHERE catid='$id' ";
		$result=$this->db->select($query);
		return $result;
	}

	public function catUpdate($catName,$id){
		$catName=$this->fm->validation($catName);
		$catName=mysqli_real_escape_string($this->db->link,$catName);
		$id=mysqli_real_escape_string($this->db->link,$id);

		if(empty($catName)){
			$msg="<span style='font-size: 18px; color: red;'> Categoy field can't be empty</span>";
			return $msg;
		}else{
			$query="UPDATE category_table SET catName='$catName' WHERE catId='$id';";
			$updated_row=$this->db->update($query);
			if($updated_row){
				$msg="<span style='font-size: 18px; color: green;'> Category updated successfully   </span>";
				return $msg;
			}else{
				$msg="<span style='font-size: 18px; color: red;'> Categoy not updated </span>";
			return $msg;
			}
		}


						
	}
	public function delCatById($id){
		$query="DELETE FROM category_table WHERE catid='$id'";
		$result=$this->db->delete($query);
		if($result){
			$msg="<span style='font-size: 18px; color: green;'> Category deleted successfully   </span>";
				return $msg;
		}else{
			$msg="<span style='font-size: 18px; color: red;'> Categoy not deleted </span>";
			return $msg;
			}

	}



}



 ?>