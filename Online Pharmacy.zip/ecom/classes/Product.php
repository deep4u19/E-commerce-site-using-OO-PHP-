<?php 
	$filepath=realpath(dirname(__FILE__));
	include_once ($filepath.'/../lib/database.php');
	include_once ($filepath.'/../helpers/format.php');
?>

<?php 
class Product {
	private $db;
	private $fm;
	public function __construct(){

		$this->db=new Database();
		$this->fm=new Format();

	}

	public function productInsert($data,$file){
		$productName=$this->fm->validation($data['productName']);
		$productName=mysqli_real_escape_string($this->db->link,$data['productName']);

		$catId=$this->fm->validation($data['catId']);
		$catId=mysqli_real_escape_string($this->db->link,$data['catId']);

		$brandId=$this->fm->validation($data['brandId']);
		$brandId=mysqli_real_escape_string($this->db->link,$data['brandId']);

		$chemical=$this->fm->validation($data['chemical']);
		$chemical=mysqli_real_escape_string($this->db->link,$data['chemical']);

		$body=$this->fm->validation($data['body']);
		$body=mysqli_real_escape_string($this->db->link,$data['body']);

		$price=$this->fm->validation($data['price']);
		$price=mysqli_real_escape_string($this->db->link,$data['price']);

		$type=$this->fm->validation($data['type']);
		$type=mysqli_real_escape_string($this->db->link,$data['type']);

		$medType=$this->fm->validation($data['medType']);
		$medType=mysqli_real_escape_string($this->db->link,$data['medType']);

		$tabletCount=$this->fm->validation($data['tabletCount']);
		$tabletCount=mysqli_real_escape_string($this->db->link,$data['tabletCount']);

		$important=$this->fm->validation($data['important']);
		$important=mysqli_real_escape_string($this->db->link,$data['important']);

		$warning=$this->fm->validation($data['warning']);
		$warning=mysqli_real_escape_string($this->db->link,$data['warning']);

		$howUse=$this->fm->validation($data['howUse']);
		$howUse=mysqli_real_escape_string($this->db->link,$data['howUse']);

		$precaution=$this->fm->validation($data['precaution']);
		$precaution=mysqli_real_escape_string($this->db->link,$data['precaution']);

		$uses=$this->fm->validation($data['uses']);
		$uses=mysqli_real_escape_string($this->db->link,$data['uses']);

		$sEffect=$this->fm->validation($data['sEffect']);
		$sEffect=mysqli_real_escape_string($this->db->link,$data['sEffect']);

		$wiki=$this->fm->validation($data['wiki']);
		$wiki=mysqli_real_escape_string($this->db->link,$data['wiki']);


		$permitted=array('jpg','jpeg','png','gif');
		$file_name=$file['image']['name'];
		$file_size=$file['image']['size'];
		$file_temp=$file['image']['tmp_name'];
		$div=explode('.',$file_name);
		$file_ext=strtolower(end($div));
		$unique_image=substr(md5(time()),0,10).'.'.$file_ext;
		$uploaded_image="upload/".$unique_image;



		if($productName==''|| $catId==''|| $brandId==''|| $chemical==''|| $price==''|| $body==''|| $type==''||$file_name==''||$medType==''||$tabletCount==''){
			$msg="<span style='font-size: 18px; color: red;'> No field can be empty..</span>";
			return $msg;
			}else{if($file_size>1048576){
						$msg="<span style='font-size: 18px; color: red;'> You can upload file less than 1mb</span>";
					return $msg;
						}elseif(in_array($file_ext,$permitted)===false){
							$msg="<span style='font-size: 18px; color: red;'> You can upload only:-".implode(',',$permitted)."</span>";
					return $msg;
					}else{
				move_uploaded_file($file_temp,$uploaded_image);
				$query="INSERT INTO product_table(productName,catId,brandId,chemical,body,price,image,type,medType,tabletCount,important,warning,
					howUse,precaution,uses,sEffect,wiki )

					VALUES('$productName','$catId','$brandId','$chemical','$body','$price','$uploaded_image','$type','$medType','$tabletCount','$important','$warning','$howUse','$precaution','$uses','$sEffect','$wiki')";

				$result=$this->db->insert($query);
				if($result){
					$msg="<span style='font-size: 18px; color: green;'>Product inserted successfully</span>";
					return $msg;

				}
				else{
					$msg="<span style='font-size: 18px; color: red;'>Product wasn't inserted..</span>";
					return $msg;
				}


			} }

	}
	public function getAllProduct(){
		$query="SELECT product_table.*,category_table.catName,brand_table.brandName
		FROM product_table 
		INNER JOIN category_table
		ON product_table.catId=category_table.catId
		INNER JOIN brand_table
		ON product_table.brandId=brand_table.brandId
		ORDER BY product_table.productId DESC";
		$result=$this->db->select($query);
		return $result;
	}

	public function getProById($id){
		$query="SELECT * FROM product_table WHERE productid='$id' ";
		$result=$this->db->select($query);
		return $result;
	}
	public function productUpdate($data,$file,$id){
		$productName=$this->fm->validation($data['productName']);
		$productName=mysqli_real_escape_string($this->db->link,$data['productName']);

		$catId=$this->fm->validation($data['catId']);
		$catId=mysqli_real_escape_string($this->db->link,$data['catId']);

		$brandId=$this->fm->validation($data['brandId']);
		$brandId=mysqli_real_escape_string($this->db->link,$data['brandId']);

		$chemical=$this->fm->validation($data['chemical']);
		$chemical=mysqli_real_escape_string($this->db->link,$data['chemical']);

		$body=$this->fm->validation($data['body']);
		$body=mysqli_real_escape_string($this->db->link,$data['body']);

		$price=$this->fm->validation($data['price']);
		$price=mysqli_real_escape_string($this->db->link,$data['price']);

		$type=$this->fm->validation($data['type']);
		$type=mysqli_real_escape_string($this->db->link,$data['type']);

		$medType=$this->fm->validation($data['medType']);
		$medType=mysqli_real_escape_string($this->db->link,$data['medType']);

		$tabletCount=$this->fm->validation($data['tabletCount']);
		$tabletCount=mysqli_real_escape_string($this->db->link,$data['tabletCount']);

		$important=$this->fm->validation($data['important']);
		$important=mysqli_real_escape_string($this->db->link,$data['important']);

		$warning=$this->fm->validation($data['warning']);
		$warning=mysqli_real_escape_string($this->db->link,$data['warning']);

		$howUse=$this->fm->validation($data['howUse']);
		$howUse=mysqli_real_escape_string($this->db->link,$data['howUse']);

		$precaution=$this->fm->validation($data['precaution']);
		$precaution=mysqli_real_escape_string($this->db->link,$data['precaution']);

		$uses=$this->fm->validation($data['uses']);
		$uses=mysqli_real_escape_string($this->db->link,$data['uses']);

		$sEffect=$this->fm->validation($data['sEffect']);
		$sEffect=mysqli_real_escape_string($this->db->link,$data['sEffect']);

		$wiki=$this->fm->validation($data['wiki']);
		$wiki=mysqli_real_escape_string($this->db->link,$data['wiki']);



		$permitted=array('jpg','jpeg','png','gif');
		$file_name=$file['image']['name'];
		$file_size=$file['image']['size'];
		$file_temp=$file['image']['tmp_name'];
		$div=explode('.',$file_name);
		$file_ext=strtolower(end($div));
		$unique_image=substr(md5(time()),0,10).'.'.$file_ext;
		$uploaded_image="upload/".$unique_image;


		if($productName==''|| $catId==''|| $brandId==''||$chemical==''|| $price==''|| $body==''|| $type==''||$medType==''||$tabletCount==''){
			$msg="<span style='font-size: 18px; color: red;'> No field can be empty..</span>";
			return $msg;
			
				}else{
					if(!empty($file_name)){
							if($file_size>1048576){
							$msg="<span style='font-size: 18px; color: red;'> You can upload file less than 1mb</span>";
							return $msg;
							}elseif(in_array($file_ext,$permitted)===false){
								$msg="<span style='font-size: 18px; color: red;'> You can upload only:-".implode(',',$permitted)."</span>";
						return $msg;
						}else{
						move_uploaded_file($file_temp,$uploaded_image);
						
						$query="UPDATE product_table SET
								productName   ='$productName',
								catId         ='$catId',
								brandId		  ='$brandId',
								chemical      ='$chemical',
								body          ='$body',
								price         ='$price',
								image         ='$uploaded_image',
								type          ='$type',
								medType       ='$medType',
								tabletCount   ='$tabletCount',
								important     ='$important',
								warning       ='$warning',
								howUse        ='$howUse',
								precaution    ='$precaution',
								uses          ='$uses',
								sEffect       ='$sEffect',
								wiki          ='$wiki'

								WHERE productId='$id'		";

						$result=$this->db->update($query);
						if($result){
							$msg="<span style='font-size: 18px; color: green;'>Product updated successfully</span>";
							return $msg;

				}

			}
			}else{
					$query="UPDATE product_table SET
								productName   ='$productName',
								catId         ='$catId',
								brandId		  ='$brandId',
								chemical      ='$chemical',
								body          ='$body',
								price         ='$price',
								type          ='$type',
								medType       ='$medType',
								tabletCount   ='$tabletCount',
								important     ='$important',
								warning       ='$warning',
								howUse        ='$howUse',
								precaution    ='$precaution',
								uses          ='$uses',
								sEffect       ='$sEffect',
								wiki          ='$wiki'
								WHERE productId='$id' ";

						$result=$this->db->update($query);
						if($result){
							$msg="<span style='font-size: 18px; color: green;'>Product updated successfully</span>";
							return $msg;

					}
				}
			}
		}
		public function delProById($id){
			$imgQuery="SELECT * FROM product_table WHERE productId='$id'";
			$getImg=$this->db->select($imgQuery);
			if($getImg){
				while($delData=$getImg->fetch_assoc()){
					unlink($delData['image']);
				}
			}

			$query="DELETE FROM product_table WHERE productId='$id'";
			$result=$this->db->delete($query);
			return $result;
			if($result){
				$msg="<span style='font-size: 18px; color: green;'>Product deleted successfully</span>";
				return $msg;

			}else{
				$msg="<span style='font-size: 18px; color: red;'>Product wasn't deleted..</span>";
					return $msg;
			}

		}

		public function getFeaturedProduct(){
			$query="SELECT * FROM product_table WHERE type='0' ORDER BY productId DESC LIMIT 4";
			$result=$this->db->select($query);
			return $result;

		}

	public function	getSingleProduct($id){
		$query="SELECT p.*,c.catName,b.brandName
				FROM product_table as p,category_table as c, brand_table as b
				WHERE p.catId=c.catId AND p.brandId=b.brandId AND p.productId='$id' ";
		$result=$this->db->select($query);
		return $result;

	}

	public function getPrescribedDrug(){
		$query= "SELECT * FROM product_table WHERE catId='8' ORDER BY productName ASC ";
		$result=$this->db->select($query);
		return $result;
	}

	public function getNonPrescribedDrug(){
		$query= "SELECT * FROM product_table WHERE catId='9' ORDER BY productName ASC";
		$result=$this->db->select($query);
		return $result;
	}

	public function getOtherDrug(){
		$query= "SELECT * FROM product_table WHERE catId='10'  ORDER BY productName ASC";
		$result=$this->db->select($query);
		return $result;
	}

	public function getPrescribedProduct(){
			$query="SELECT * FROM product_table WHERE catId='8' ORDER BY productId ASC LIMIT 3";
			$result=$this->db->select($query);
			return $result;

	}
	public function getNonPrescribedProduct(){
			$query="SELECT * FROM product_table WHERE catId='9' ORDER BY productId ASC LIMIT 3";
			$result=$this->db->select($query);
			return $result;

	}
	public function getOtherProduct(){
			$query="SELECT * FROM product_table WHERE catId='10' ORDER BY productId ASC LIMIT 3";
			$result=$this->db->select($query);
			return $result;

	}
	public function getRelatedProduct($chem,$prodId){
		$query = "SELECT * FROM product_table WHERE chemical='$chem' AND productId !=$prodId ORDER BY productId ASC LIMIT 3";
		$result=$this->db->select($query);
		return $result;
	}
	public function addToWish($data,$cmrId){
		$medName=$this->fm->validation($data['medName']);
		$medName=mysqli_real_escape_string($this->db->link,$data['medName']);
		$chemName=$this->fm->validation($data['chemName']);
		$chemName=mysqli_real_escape_string($this->db->link,$data['chemName']);
		if($medName==''){
			$msg="<span style='color: red;'>Medicine Name can't be empty..</span>";
			return $msg;
		}else{
			$query="INSERT INTO wish_table (cmrId,medName,chemName)
				VALUES ('$cmrId','$medName','$chemName') ";
			$result=$this->db->insert($query);
			if($result){
				$msg="<span style='color:green;'>Added to wishlist..</span>";
			    return $msg;
			} 
		}

	}

	public function getAllWishList($id){
		$query="SELECT * FROM wish_table WHERE cmrId='$id'";
		$result=$this->db->select($query);
		return $result;
	}
	public function delProductByCart($delWishId){
		$query="DELETE FROM wish_table WHERE id='$delWishId' ";
		$result=$this->db->delete($query);
		if($result){
			echo"<script>window.location='profile.php';</script>";
		}
	}


		public function delHistory($delId){
		$query="DELETE FROM history_table WHERE id='$delId' ";
		$result=$this->db->delete($query);
		if($result){
			echo"<script>window.location='profile.php';</script>";
		}
	}




	public function getSearchResult($searchChq){
		
		$query="SELECT * FROM product_table WHERE productName like '%$searchChq%' OR
		chemical like '%$searchChq%' ";
		$result=$this->db->select($query);
		// $count=mysqli_num_rows($result);
		if(!$result){
			echo"<script>window.location='noresult.php';</script>";
		}else{
			return $result;
		}
	}

	public function sendMail($data){
		$fName=$this->fm->validation($data['fName']);
		$lName=$this->fm->validation($data['lName']);
		$email=$this->fm->validation($data['email']);
		$phone=$this->fm->validation($data['phone']);
		$subject=$this->fm->validation($data['subject']);
		$message=$this->fm->validation($data['message']);
		$to = "deep4u19@gmail.com";
		$subject ="$subject";
		$from="Name : ".$fName." ".$lName."   "." Phone No: $phone"."   "." Email: $email";

		$txt = "$message";

		// Always set content-type when sending HTML email
		$headers = "$from"."\r\n";
		$result=mail($to,$subject,$txt,$headers);
		if ($result) {
			$msg="Mail Sent";
			return $msg;
		}else{
			$msg="Mail Not Sent";
			return $msg;

		}
	}

	
}
// $sql = "SELECT productName FROM product_table WHERE catId='9' ";
// $sql = "SELECT * FROM `product_table` WHERE `chemical`=\'paracetamol\' ORDER BY productId ASC LIMIT 3";

?>