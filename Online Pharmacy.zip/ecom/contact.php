<?php include 'inc/header.php' ; ?>
<?php include 'inc/navbar.php' ; ?>

<?php if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])){
        $sendMail=$pd->sendMail($_POST);
 }   

 ?>

<div class="container">
			<div class="row" style="background: #f2f2f2;margin-top: 10px;">
				<div class="col-md-7">
					<h2 class="col-sm-offset-0">Contact Form </h2> 
                    <?php if (isset($sendMail)) {
                        echo $sendMail;
                    } ?>


					<form id="contact-form" method="post" action="contact.php" role="form">

                        <div class="messages"></div>

                        <div class="controls">

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_name">Firstname *</label>
                                        <input id="form_name" type="text" name="fName" class="form-control" placeholder="Please enter your firstname *" required="required" data-error="Firstname is required.">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_lastname">Lastname *</label>
                                        <input id="form_lastname" type="text" name="lName" class="form-control" placeholder="Please enter your lastname *" required="required" data-error="Lastname is required.">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_email">Email *</label>
                                        <input id="form_email" type="email" name="email" class="form-control" placeholder="Please enter your email *" required="required" data-error="Valid email is required.">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_phone">Phone</label>
                                        <input id="form_phone" type="tel" name="phone" class="form-control" placeholder="Please enter your phone no. (Optional)">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="form_subject">Subject </label>
                                        <input id="form_phone" type="text" name="subject" class="form-control" placeholder="Subject " required="required" data-error="Subject is required.">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="form_message">Message *</label>
                                        <textarea id="form_message" name="message" class="form-control" placeholder="Message for me *" rows="4" required="required" data-error="Please,leave us a message."></textarea>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <input type="submit" name="submit" class="btn btn-success btn-send" value="Send message">
                                    <button type="reset" name="reset" class="btn btn-default">clear</button>
                                </div>
                            </div>
                            <br>	
                            <div class="row">
                                <div class="col-md-12">
                                    <p class="text-muted"><strong>*</strong> These fields are required.</p>
                                </div>
                            </div>
                        </div>

                    </form>
				</div>

				<div class="col-md-4">

					<h2 class="col-sm-offset-2" style="font-family: 'Courgette', cursive;margin-top: 18px;font-size: 37px;">The Goblins</h2><br>

					<div class="thumbnail">
						<img class="img-rounded img-responsive" src="images\goblins.jpg">

						<div class="caption">
							<h3 class="col-sm-offset-2">Meet us @</h3>
							<p ><h4 class="col-sm-offset-2"></h4>

								<p class="col-sm-offset-2" style="font-size: 15px; font-family: 'Kurale', serif;">
									Shahjalal University of Science  <br> and Technology (SUST),,<br>
									University Ave,Akhalia, <br>
									Sylhet 3114, Bangladesh.<br>

									Mobile: +8801737079457<br>
									Mail: teamthegoblins@gmail.com
								</p>
							</p>
							
						</div>
					</div>

					
				</div>
				</div>
			</div>



<?php include 'inc/slider.php' ; ?>
<?php include 'inc/footer.php' ; ?>