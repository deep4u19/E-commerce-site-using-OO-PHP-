<?php include 'inc/header.php' ; ?>
<?php include 'inc/navbar.php' ; ?>

<div class="container">
	<div class="row" align="center">
		<div class="col-md-12 animated pulse infinite">
			<h1 style="color: red;">404 NOT FOUND</h1>
			
		</div>
		
	</div>
	

</div>





<?php include 'inc/slider.php' ; ?>
<?php include 'inc/footer.php' ; ?>