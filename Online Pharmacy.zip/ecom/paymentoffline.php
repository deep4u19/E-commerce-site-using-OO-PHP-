<?php include 'inc/header.php' ; ?>
<?php include 'inc/navbar.php' ; ?>
<?php 
		$login=Session::get("cuslogin");
		if ($login==false) {
			echo "<script>window.location='login.php';</script>";
		}

 ?>
 <?php if(!$getData){

			echo "<script>window.location='index.php';</script>";

					 	} ?>

 <?php if (isset($_GET['orderid'])&& $_GET['orderid']=='order') {
 	$cmrId=Session::get('cmrId');
 	$insertOrder=$ct->orderProduct($cmrId);
 	$delData=$ct->delCustomerCart();
 	echo "<script>window.location='success.php';</script>";
 }

  ?>
 

<div class="container payment-cont">
	<div class="row">
		<div class="col-md-7">
			<div class="main">
			    <div class="content1">
			    	<div class="cartoption" style="background: #f2f2f2;">		
						<div class="cartpage payment-cartpage">
						    	<h2 style="color:#333;font-size: 33px;font-family: 'Bitter', serif;">Your Cart</h2>
							<table class="tblone">
							<tr>
								<th width="5%">SL</th>
								<th width="25%">Product</th>
								
								<th width="20%">Price</th>
								<th width="20%">Quantity</th>
								<th width="25%">Total Price</th>
								
							</tr>
							<?php 
								$getPro=$ct->getCartProduct();
								if($getPro){
									$i=0;
									$sum=0;
									while($result=$getPro->fetch_assoc()){
										$i++;
							 ?>
							<tr>
								<td><?php echo($i)."." ;?></td>
								<td><?php echo $result['productName'] ;?></td>
								<td>$ <?php echo $result['price'] ;?></td>
								<td>				
										<?php echo($result['quantity']); ?>
										
								</td>
								<td>$<?php
										$total=$result['price']*$result['quantity'];
									 	echo (number_format("$total",2)) ;
									 ?>									 	
								</td>
								

							</tr>
								<?php $sum=$sum+$total;
									  $vat=$sum*.1;
									  $gtotal=$sum+$vat;
									  
								 ?>
							<?php } } ?>
							
							
						</table>
						<div>
						<a href="cart.php" class="pull-left editcrt"><button class="btn btn-success">Edit cart</button></a>
						<table style="float:right;text-align:left;" width="40%" class="sub">
							<tr>
								<th>Sub Total : </th>
								<td>$ <?php echo(number_format("$sum",2)); ?>
								 	
								</td>
							</tr>
							<tr>
								<th>VAT : </th>
								<td>$ <?php echo(number_format("$vat",2))." &nbsp &nbsp"."( 10% )"; ?></td>
							</tr>
							<tr>
								<th>Grand Total :</th>
								<td>$ <?php echo(number_format("$gtotal",2)); ?></td>
							</tr>
					   </table>
					   </div>
					   
					</div>

					
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
			
		</div>




	<div class="col-md-5 pmnt" style="background: #f2f2f2;">
		
		<h3 class="" style="font-size: 33px;font-family: 'Bitter', serif;margin-top: 31px;
    border-bottom: 1px solid #ddd;">Your account informations</h3><br>
		<div class="row" align="center">
			<div class="col-md-12">

				<!--Table-->
				<?php 
				 $id=Session::get('cmrId');
				 $getData=$cmr->getCustomerData($id);
				 if($getData){
				 	while ($result=$getData->fetch_assoc()) {
				 		

				 ?>
				
					<table class="table table-striped tble">


					    <!--Table body-->
					    <tbody>
					        <tr>
					            <td width="10%">Name</td>
					            <td width="5%">:</td>
					            <td width="50%"><?php echo $result['name'] ;?></td>
					        </tr>
					        <tr>
					            <td width="10%">Address</td>
					            <td width="5%">:</td>
					            <td width="30%"><?php echo $result['address'] ;?></td>
					        </tr>
					        <tr>
					            <td width="10%">City</td>
					            <td width="5%">:</td>
					            <td width="30%"><?php echo $result['city'] ;?></td>
					        </tr>
					        <tr>
					            <td width="10%">Country</td>
					            <td width="5%">:</td>
					            <td width="30%"><?php echo $result['country'] ;?></td>
					        </tr>
					         <tr>
					            <td width="10%">Zip Code</td>
					            <td width="5%">:</td>
					            <td width="30%"><?php echo $result['zip'] ;?></td>
					        </tr>
					        <tr>
					            <td width="10%">Phone No</td>
					            <td width="5%">:</td>
					            <td width="30%"><?php echo $result['phone'] ;?></td>
					        </tr>
					        <tr>
					            <td width="10%">Email</td>
					            <td width="5%">:</td>
					            <td width="30%"><?php echo $result['email'] ;?></td>
					        </tr>
					        <tr>
					            <td width="10%"></td>
					            <td width="5%"></td>
					            <td width="30%"><a href="editProfile.php"><button class="btn btn-primary">Update Details</button></a></td>
					        </tr>
					    </tbody>
					    <!--Table body-->

					</table>
					<!--Table-->
					<?php } } ?>
			</div>

			<div></div>
		</div>
		
	</div>

		<div class="col-md-12 payment-order">
			<a href="?orderid=order" class="col-md-offset-5">
				<button class="">Order</button>
			</a>
		</div>
			
		</div>
	</div>
	
</div>




<?php include 'inc/slider.php' ; ?>
<?php include 'inc/footer.php' ; ?>