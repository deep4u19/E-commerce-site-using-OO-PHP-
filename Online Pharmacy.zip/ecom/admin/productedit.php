<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php include '../classes/Brand.php' ?>
<?php include '../classes/Category.php' ?>
<?php include '../classes/Product.php' ?>

<?php 
    if(!isset($_GET['proid'])|| isset($_GET['proid'])==NULL){
        echo '<script>window.location="productlist.php";</script>';
    }else{
        $id=$_GET['proid'];
    }
    $pd=new Product();
    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])){
        $updateProduct=$pd->productUpdate($_POST,$_FILES,$id);
    }

 ?>


<div class="grid_10">
    <div class="box round first grid">
        <h2>Add New Product</h2>
        <div class="block"> 
        <?php if(isset($updateProduct)){
            echo $updateProduct;
        } ?> 
                   
        <?php $getProd=$pd->getProById($id);
            if($getProd){
                while($value=$getProd->fetch_assoc()){            
         ?>  
         <form action="" method="post" enctype="multipart/form-data">
            <table class="form">
               
                <tr>
                    <td>
                        <label>Name</label>
                    </td>
                    <td>
                        <input type="text" name="productName" value="<?php echo $value['productName'];?>"  class="medium" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Category</label>
                    </td>
                    <td>
                        <select id="select" name="catId">
                            <option>Select Category</option>

                            <?php 
                                $cat=new Category();
                                $getCat=$cat->getAllCat();
                                if($getCat){
                                    while($result=$getCat->fetch_assoc()){

                             ?>
                            <option <?php if($value['catId']==$result['catId']){?>
                                        selected="Selected";
                                    <?php } ?>
                            value="<?php echo $result['catId'] ?>;"><?php echo $result['catName'] ;?>                              
                            </option>
                            <?php } } ?>
                
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Brand</label>
                    </td>
                    <td>
                        <select id="select" name="brandId">
                        <?php 

                            $brand=new Brand();
                            $getBrand=$brand->getAllBrand();
                            if($getBrand){
                                while($result=$getBrand->fetch_assoc()){

                         ?>
                            
                            <option <?php if($value['brandId']==$result['brandId']){?>
                                        selected="Selected";
                                    <?php } ?>
                            value="<?php echo $result['brandId'] ?>;"><?php echo $result['brandName'] ;?>                              
                            </option>
                        <?php } } ?>

                    
                        </select>
                    </td>
                </tr>

                <tr>
                    <td>
                        <label>Chemical Name</label>
                    </td>
                    <td>
                        <input type="text" name="chemical" placeholder="Enter chemical name" class="medium" value="<?php echo $value['chemical'];?>"/>
                    </td>
                </tr>
                
                 <tr>
                    <td style="vertical-align: top; padding-top: 9px;">
                        <label>Description</label>
                    </td>
                    <td>
                        <textarea class="tinymce" name="body">
                            <?php echo $value['body'] ;?>
                        </textarea>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Price</label>
                    </td>
                    <td>
                        <input type="text" name="price" value="<?php echo $value['price'];?>" class="medium" />
                    </td>
                </tr>
            
                <tr>
                    <td>
                        <label>Upload Image</label>
                    </td>
                    <td>
                        <img src=" <?php echo $value['image'] ;?> " height="80px" width="200px"><br>
                        <input type="file" name="image" />
                    </td>
                </tr>
                
                <tr>
                    <td>
                        <label>Product Type</label>
                    </td>
                    <td>
                        <select id="select" name="type">
                            <option>Select Type</option>
                            <?php if($value['type']==0){?>
                            <option selected="Selected" value="0">Featured</option>
                            <option value="1">Non-Featured</option>
                            <?php }else{?>
                                <option value="0">Featured</option>
                                <option selected="selected" value="1">Non-Featured</option>
                             <?php } ?>
                        </select>
                    </td>
                </tr>

                                <tr>
                    <td>
                        <label>Medicine Type</label>
                    </td>
                    <td>
                        <select id="select" name="medType">
                            <option>Select Type</option>
                            <?php if($value['medType']==0){?>
                            <option selected="Selected" value="0">Tablet</option>
                            <option value="1">Capsule</option>
                            <option value="2">Serum</option>
                            <option value="3">Others</option>
                            <?php }elseif($value['medType']==1){?>
                            <option value="0">Tablet</option>
                            <option selected="Selected" value="1">Capsule</option>
                            <option value="2">Serum</option>
                            <option value="3">Others</option>
                            <?php }elseif($value['medType']==2){ ?>
                            <option value="0">Tablet</option>
                            <option value="1">Capsule</option>
                            <option selected="Selected" value="2">Serum</option>
                            <option value="3">Others</option>
                            <?php }else{ ?>
                            <option value="0">Tablet</option>
                            <option value="1">Capsule</option>
                            <option value="2">Serum</option>
                            <option selected="Selected" value="3">Others</option>
                            <?php } ?>    
                        </select>
                    </td>
                </tr>

                <tr>
                    <td>
                        <label>Med Amount (For Serum mL)</label>
                    </td>
                    <td>
                        <input type="text" name="tabletCount" placeholder="Enter total tablet numbers in a strip" class="medium" value="<?php echo $value['tabletCount'];?>"/>
                    </td>
                </tr>

                <div>
                    <tr ><td><h3 style="margin-top: 20px;border-bottom: 1px dashed;">Additional Infos</h3></td></tr>

                    <div>

                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Important &nbsp&nbsp&nbsp :</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="important">
                                    <?php echo $value['important'];?>
                                </textarea>
                            </td>
                        </tr>

                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Warning &nbsp&nbsp&nbsp :</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="warning">
                                    <?php echo $value['warning'];?>
                                </textarea>
                            </td>
                        </tr>

                        
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>How to use &nbsp&nbsp&nbsp :</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="howUse">
                                    <?php echo $value['howUse'];?>
                                </textarea>
                            </td>
                        </tr>

                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Precautions &nbsp&nbsp&nbsp :</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="precaution">
                                    <?php echo $value['precaution'];?>
                                </textarea>
                            </td>
                        </tr>
                    </div>



                    <div>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Used For &nbsp&nbsp&nbsp :</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="uses">
                                    <?php echo $value['uses'];?>
                                </textarea>
                            </td>
                        </tr>

                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Side Effects &nbsp&nbsp&nbsp :</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="sEffect">
                                    <?php echo $value['sEffect'];?>
                                </textarea>
                            </td>
                        </tr>

                    <tr>
                        <td>
                            <label>Wiki Embed</label>
                        </td>
                        <td>
                            <input type="text" name="wiki" placeholder="Enter Wiki link here" class="medium" value="<?php echo $value['wiki'];?>" />
                        </td>
                     </tr>
                        
                    </div>

                </div>

                <tr>
                    <td></td>
                    <td>
                        <input type="submit" name="submit" Value="Save" />
                    </td>
                </tr>
            </table>
            </form>
            <?php } } ?>
        </div>
    </div>
</div>
<!-- Load TinyMCE -->
<script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function () {
        setupTinyMCE();
        setDatePicker('date-picker');
        $('input[type="checkbox"]').fancybutton();
        $('input[type="radio"]').fancybutton();
    });
</script>
<!-- Load TinyMCE -->
<?php include 'inc/footer.php';?>


