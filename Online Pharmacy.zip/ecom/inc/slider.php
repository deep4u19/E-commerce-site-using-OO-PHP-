		<div class="container-fluid slide-back-img product-page">
			
			<div id="mySlide">
				<div id="myCarousel" class="carousel slide" data-interval="8000" 
						data-ride="carousel" data-pause="null">
					
					

					<h1 style="font-family: 'Bitter', serif;color: #e6e6e6;">Listen to some of our happiest customers..</h1>

					<div class="carousel-inner ">
						<div class="item active">
								<h4>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
									tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
									quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
									consequat. 
								</h4>
								<p>--<i>Jack Han</i></p>

								
						</div>

						<div class="item ">

								<h4>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
									tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
									quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
									consequat.
								</h4>
								<p>--<i>Jack Han</i></p>
							
									
						</div>

						<div class="item ">

									<h4>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
									tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
									quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
									consequat.
									</h4>
									<p>--<i>Jack Han</i></p>
							
							
						</div>
						<p><a class="btn btn-large btn-success" >View All</a></p>
						<ol class="carousel-indicators caro-dot">
						<li data-target="#myCarousel" data-slide-to="0" class="active"></li>				
						<li data-target="#myCarousel" data-slide-to="1" ></li>	
						<li data-target="#myCarousel" data-slide-to="2" ></li>				
					</ol>
					</div>


				</div>
			</div>
			
		</div>