<?php include 'inc/header.php' ; ?>
<?php include 'inc/navbar.php' ; 
$login=Session::get("cuslogin");
?>
<?php if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit-btn'])){
		if ($login==false){
			echo "<script>window.location='login.php';</script>";
		}else{
			$cmrId=Session::get('cmrId');
			$addWish=$pd->addToWish($_POST,$cmrId);
		}


	
} ?>



<div class="container cat-cont">
	<div class="row" style="margin-top: -12px !important;">
	<h1 align="center">All the products of this website are listed here..</h1>
	</div>
	<div class="row cat-row equal">
		
		

		<div class="col-md-3 cat-main ">
			<h3>Prescribed Drugs</h3>
			<?php $prescribedDrug=$pd->getPrescribedDrug();
			if($prescribedDrug){
				 $io=0;
				while ($result=$prescribedDrug->fetch_assoc()) {
					$io++;
			?>
				<div class="col-md-offset-1">

					<a href="product.php?proid=<?php echo $result['productId']; ?>"><p ><i class="fas fa-plus " style="margin-right: 5px; color: red;"></i><?php echo $result['productName'] ;?></p></a>


				</div>
			<?php } } ?>


		</div>
		
		

		<div class="col-md-3 cat-main ">
			<h3>Non Prescribed Drugs</h3>
			<?php  $nonPrescribedDrug=$pd->getNonPrescribedDrug();
			if($nonPrescribedDrug){
				$ioo=0;
				while ($result=$nonPrescribedDrug->fetch_assoc()) {
					$ioo++;
			?>
			<div class="col-md-offset-1">
				<a href="product.php?proid=<?php echo $result['productId']; ?>"><p><i class="fas fa-plus" style="margin-right: 5px; color: red;"></i>
				<?php echo $result['productName'] ;?></p></a>
			</div>
			
			<?php } } ?>

			<?php  

			?>
		</div>

		
		

		

		
		
		<div class="col-md-3 cat-main  ">
			<h3>Other Drugs</h3>
			<?php  $otherDrug=$pd->getOtherDrug();
				if($otherDrug){
					$iooo=0;
				while ($result=$otherDrug->fetch_assoc()) {
					$iooo++;
			?>
			<div class="col-md-offset-1">
				<a href="product.php?proid=<?php echo $result['productId']; ?>"><p><i class="fas fa-plus " style="margin-right: 5px; color: red;"></i><?php echo $result['productName'] ;?></p> </a>
			</div>
			<?php } } ?>

			<?php  

			?>
			
		</div>

		<div class="col-md-3 cat-main last-child ">
			<h3>Wishlist</h3>
			<?php if(isset($addWish)) {
				echo $addWish;
			} ?>
			<form method="post">
			 <div class="form-group">
			    <input type="text" class="form-control" id="text" name="medName" placeholder="Enter Medcine Name (required)">
			 </div>
			 <div class="form-group">
			    <input type="text" class="form-control" id="text" name="chemName" placeholder="Enter Chemical Name (optional)">
			 </div>
			 <?php if ($login==false){?><p style="color: blue;">**Login Required**</p><?php } ?>
			 <button class="btn btn-success" name="submit-btn">Submit</button>
			 <a href="profile.php"><input type="button" class="btn btn-primary" name="view-wishlist" value="View Wishlist"></a>
			</form>



			<form>
			<div class="form-group">
			<input style="margin-top: 6px;" type="text" class="form-control" name="uploadPres" placeholder="Upload Your Prescription" disabled="">
			</div>
			<button disabled="disabled" style="margin-bottom: 8px;" class="btn btn-success" name="upload-pres">Upload</button>
			</form>



		</div>

		

		
	</div>
			<h3 align="center" >**Note: Prescribed drugs will only be delivered after uploading prescription..</h5>
	

</div>
<?php Session::set("proCount",$io); 
			Session::set("NproCount",$ioo);
			Session::set("OCount",$iooo);

			?>




<?php include 'inc/slider.php' ; ?>
<?php include 'inc/footer.php' ; ?>