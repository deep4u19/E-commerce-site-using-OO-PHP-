<?php include 'inc/header.php' ; ?>
<?php include 'inc/navbar.php' ; ?>

<div class="container" style="    background: #f2f2f2;">
	<div class="row" >

		
		<?php if(isset($getSearch)==''){
					echo "<h3 style='color:red;text-align: center;
 						   padding-bottom: 17px;'>Please enter a valid search query..</h3>";		

				}else{ ?>

				<div class="col-md-12 ">
			<h1 align="center" class="animated pulse" style="color: #333;">Your Search Matches Following Product..</h1>
		</div>

				 <?php while ($result=$getSearch->fetch_assoc()) {
				 	?>
	</div>
	<div class="row">

 			
				
				 	
				 	<div style="width: 73%;
							    background: #e6e6e6;
							    margin: 0px auto;
							    border-radius: 3px;
							    padding: 1px 0px 5px;
							    margin-bottom: 10px;

				    ">
					<div style="margin: 0px auto;
			    					text-align: justify;
			    					margin-left: 20px;">

			    		<form class="form-inline">
			    		<div class="form-group" style="width: 45%;">
						<h4>Medicine Name :&nbsp<?php echo $result['productName'];?></h4></div>
						<div class="form-group" style="width: 45%;">
						<h4>Drug Name :&nbsp<?php echo $result['chemical'];?></h4></div>
						<div class="form-group" style="margin-top: 5px;">
						<a href="product.php?proid=<?php echo $result['productId'];?>" class="btn btn-primary">Details</a>
						</div>
						</form>
						</div>

					</div>
				 
			
				
				<?php } } ?>
			
			
			
		</div>
		
</div>
	






<?php include 'inc/slider.php' ; ?>
<?php include 'inc/footer.php' ; ?>