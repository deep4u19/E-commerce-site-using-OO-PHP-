<?php include 'inc/header.php' ?>
<?php include 'inc/navbar.php' ?>
<?php 
		$login=Session::get("cuslogin");
		if ($login==true) {
			echo "<script>window.location='profile.php';</script>";
			// header('Location: '.$_SERVER['PHP_SELF']);
  	// 		die;
  		}

 ?>

<?php if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['login'])){
				
         		$cusLogin=$cmr->customerLogin($_POST);

         } ?>

<div class="container-fluid">
	<div class="row">
    <div class="content-login">
    	
    	 <div class="login_panel">
    	 	<?php if(isset($cusLogin)){
	    			echo ($cusLogin);
	    		} ?>
    	 	

        	<h3>Existing Customers</h3>
        	<p>Sign in with the form below.</p>
        	<form action="" method="post">
                	<input name="email" placeholder="Email" type="text">
                	<input name="pass-login" placeholder="Password" type="password">

                	<button class="btn btn-primary" name="login" >Sign In</button>
                	
                    
                 </form>
                 
                 
                 <p class="note">If you forgot your passoword just enter your email and click <a href="#">here</a></p>
         </div>
                    

                 


         <?php if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['register'])){
         		$customerReg=$cmr->customerRegistration($_POST);

         } ?>




    	<div class="register_account">
	    		<?php if(isset($customerReg)){
	    			echo($customerReg);
	    		} ?>
    		<h3>Register New Account</h3>
    		<form action="" method="post">
		   			 <table>
		   				<tbody>
						<tr>
						<td>
							<div>
							<input type="text" placeholder="Name" name="name">
							</div>
							
							<div>
							   <input type="text" placeholder="City" name="city">
							</div>
							
							<div>
								<input type="text" placeholder="Zip-Code" name="zip">
							</div>
							<div>
								<input type="text" placeholder="Email" name="email">
							</div>
		    			 </td>
		    			<td>
						<div>
							<input type="text" placeholder="Address" name="address">
						</div>
		    			<div>
							<input type="text" placeholder="Country" name="country">
						</div>		        
	
		           <div>
		          <input type="text" placeholder="Phone No." name="phone">
		          </div>
				  
				  <div>
					<input type="text" placeholder="Password" name="pass-signup">
				</div>
		    	</td>
		    </tr> 
		    </tbody></table> 
		   <div class="search"><div><button class="btn btn-success" name="register">Create Account</button></div></div>
		    <p class="terms">By clicking 'Create Account' you agree to the <a href="#">Terms &amp; Conditions</a>.</p>
		    <div class="clear"></div>
		    </form>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
</div>


















<?php include 'inc/footer.php' ?>