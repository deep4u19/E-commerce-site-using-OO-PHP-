<?php
	$filepath=realpath(dirname(__FILE__));
	include ($filepath.'/../lib/session.php');
	Session::checkLogin();
	include_once ($filepath.'/../lib/database.php');
	include_once ($filepath.'/../helpers/format.php');




  ?>



<?php 


class AdminLogin
{	

	private $db;
	private $fm;
	
	public function __construct()
	{
		$this->db=new Database();
		$this->fm=new Format();
		
	}

	public function adminLogin($adminUsername,$adminPass){
		$adminUsername=$this->fm->validation($adminUsername);
		$adminPass=$this->fm->validation($adminPass);

		$adminUsername=mysqli_real_escape_string($this->db->link,$adminUsername);
		$adminPass=mysqli_real_escape_string($this->db->link,$adminPass);

		if(empty($adminUsername)||empty($adminPass)){
			$loginmsg="Username or Password can't be empty";
			return $loginmsg;
		}else{
			$query="SELECT * FROM admin_login_table WHERE adminUsername= '$adminUsername' And adminPass='$adminPass' ";
			$result=$this->db->select($query);
			if($result!==false){
				$value=$result->fetch_assoc();
				Session::set("adminLogin",true);
				Session::set("adminId",$value['adminId']);
				Session::set("adminUsername",$value['adminUsername']);
				Session::set("adminName",$value['adminName']);
				header("Location:dashboard.php");
			}else{
				$loginmsg="Username or Password doesn't match";
				return $loginmsg;
			}
		}





	}
}


 ?>