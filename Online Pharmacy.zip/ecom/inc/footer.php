<div class="container-fluid ">
			<div class="row footer-row1">
				<div class="col-md-8">
					<div class="col-md-3 ">
						<h3>General</h3>
						<li><a href="index.php">Home</a></li>
						<li><a href="cart.php">Shopping cart</a></li>
						<li><a href="payment.php">Check Out</a></li>
						<li><a href="#">Blog</a></li>
					</div>

					<div class="col-md-3">
						<h3>Products</h3>
						<li><a href="#">Best sellers</a></li>
						<li><a href="#">Categories</a></li>
						<li><a href="#">Certification</a></li>
						<li><a href="#">Blog</a></li>
					</div>

					<div class="col-md-3">
						<h3>Help & support</h3>
						<li><a href="#">Contact us</a></li>
						<li><a href="#">User manual</a></li>
						<li><a href="#">FAQ</a></li>
						<li><a href="#">Cancellation policy</a></li>
						<li><a href="#">Return policy</a></li>
						<li><a href="#">Shipping Policy</a></li>
					</div>

					<div class="col-md-3">
						<h3>Account</h3>
						<li><a href="profile.php">Your account</a></li>
						<li><a href="login.php">Sign up</a></li>
						<li><a href="login.php">Log in</a></li>
						<li><a href="#">Forget password</a></li>
					</div>

					<div class="col-md-6">
						<div class="payment">
							<h4 style="color: #fff;">We support</h4>
							<img src="images/Card.png"><br><br>
							
							
						</div>
					
					</div>

					<div class="col-md-6 contact-icon">
						
						<div class="col-md-3">
							<a href=""><span class="con-icon icon-fb"><i class="fab fa-facebook-f fa-3x icon-cls"></i></span></a>
						</div>
						<div class="col-md-3">
							<a href=""><span class="con-icon icon-gp"><i class="fab fa-google-plus-g fa-3x"></i></span></a>
						</div>
						<div class="col-md-3">
							<a href=""><span class="con-icon icon-tw"><i class="fab fa-twitter fa-3x icon-cls"></i></span></a>
						</div>
						<div class="col-md-3">
							<a href=""><span class="con-icon icon-in"><i class="fab fa-linkedin-in fa-3x icon-cls"></i></span></a>
						</div>
					</div>

				</div>



				<div class="col-md-3 support">
					<div class="order-line ">
						

						<h4 class="one"><span style="color: #337ab7;">Order Line 1 </span> : 0147852369</h4>
						<h4><span style="color: #337ab7;">Order Line 2 </span> : 0147852369</h4>
					</div>

					<div class="col-md-12">
						<div class="col-md-6" style="float: left;">
							<h4 style="color: #337ab7">Business hour</h4>
							<p>Mon to Fri, 7:00am - 8:00pm</p>
							<p>Sat, 7:30am - 5:30pm</p>
							<p>Sun, 8:30am - 5:00pm</p><br>
							<p><i>All times Central Standard Time (CST)</i></p>

						</div>
						<div class="col-md-6" style="float: right;border-left:1px solid  #337ab7;">
							<h4 style="color: #337ab7">Holiday hour</h4>
							<p>Dec 24th, 7:00am - 6:00pm</p>
							<p>Dec 25th, Closed</p>
							<p>Dec 31st, 7:00am - 6:00pm </p>
						</div>
					</div>


					
				</div>
				<div class="copyright">
					<h3><a href="aboutus.php">Copyright &copy; 2018 : &nbsp<span style="color: #66ff66">The Goblins</span></a></h3><br><br>
				</div>

				<div class="col-md-12">
					
				</div>


			</div>
		

			

		</div>
		
				<div>
					<!-- <a href="#" class="back-to-top" style="display: inline;">
 
						<span class="backTop"><i class="fas fa-angle-double-up"></i></span>
					 
					</a> -->
					<a href="#0" class="cd-top js-cd-top">Top</a>
					

				</div>


		<script type="text/javascript" src="js/main.js"></script> <!-- Resource JavaScript -->
		<script defertype="text/javascript" src="js/fontawesome-all.js"></script>
		
		
		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript" src="js/script.js"></script>
	</body>
</html>