<?php include 'inc/header.php'; ?>
<?php
if(empty($_GET['proid']) || $_GET['proid']==null){
	echo "<script>window.location='404.php';</script>";
}else{
	$id=$_GET['proid'];
	$id=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['proid']);

 }

if($_SERVER['REQUEST_METHOD']=='POST'){
	$quantity=$_POST['quantity'];
	$addCart=$ct->addToCart($quantity,$id);
}
 ?>
<!-- nav -->
<?php include 'inc/navbar.php'; ?>
	

<!-- product contents -->


<?php include'inc/prodcont.php'; ?>



<!-- carousel -->

<?php include'inc/slider.php'; ?>

<!-- Footer starts here -->
<?php include'inc/footer.php'; ?>