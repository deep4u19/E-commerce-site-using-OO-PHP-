<?php include 'inc/header.php' ; ?>
<?php include 'inc/navbar.php' ; ?>
<?php 
		$login=Session::get("cuslogin");
		if ($login==false) {
			echo "<script>window.location='login.php';</script>";
		}

 ?>

 <?php if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])){
 			$cmrId=Session::get('cmrId');
         	$updateCmr=$cmr->customerUpdate($_POST,$cmrId);

         } ?>
<div class="container ">
	<div class="col-md-12 pro">
	<h3 class="">Update your account informations</h3><br>
	<?php if (isset($updateCmr)) {
				echo "<script>window.location='profile.php';</script>";
			} ?>
	<div class="row" align="center">
		<div class="col-md-7">
			

		<!--Table-->
		<?php 
		 $id=Session::get('cmrId');
		 $getData=$cmr->getCustomerData($id);
		 if($getData){
		 	while ($result=$getData->fetch_assoc()) {
		 		

		 ?>
		
			<table class="table table-striped tble">


			    <!--Table body-->
			    <form method="post" action="">
			    <tbody>
			        <tr>
			            <td width="10%" class="pad">Name</td>
			            <td width="5%" class="pad">:</td>
			            <td width="50%"><input type="text" name="name" value=" <?php echo $result['name'] ;?>"></td>
			        </tr>
			        <tr>
			            <td width="10%" class="pad">Address</td>
			            <td width="5%" class="pad">:</td>
			            <td width="30%" ><input type="text" name="address" value=" <?php echo $result['address'] ;?>"></td>
			        </tr>
			        <tr>
			            <td width="10%" class="pad">City</td>
			            <td width="5%" class="pad">:</td>
			            <td width="30%"><input type="text" name="city" value=" <?php echo $result['city'] ;?>"></td>
			        </tr>
			        <tr>
			            <td width="10%" class="pad">Country</td>
			            <td width="5%" class="pad">:</td>
			            <td width="30%"><input type="text" name="country" value=" <?php echo $result['country'] ;?>"></td>
			        </tr>
			         <tr>
			            <td width="10%" class="pad">Zip Code</td>
			            <td width="5%" class="pad">:</td>
			            <td width="30%"><input type="text" name="zip" value=" <?php echo $result['zip'] ;?>"></td>
			        </tr>
			        <tr>
			            <td width="10%" class="pad">Phone No</td>
			            <td width="5%" class="pad">:</td>
			            <td width="30%"><input type="text" name="phone" value=" <?php echo $result['phone'] ;?>"></td>
			        </tr>
			        <tr>
			            <td width="10%" class="pad">Email</td>
			            <td width="5%" class="pad">:</td>
			            <td width="30%"><?php echo $result['email'] ;?></td>
			        </tr>
			        <tr>
			            <td width="10%" class="pad"></td>
			            <td width="5%" class="pad"></td>
			            <td width="30%"><a href="editProfile.php"><button class="btn btn-primary" name="submit">Update Details</button></a></td>
			        </tr>
			    </tbody>
			    <!--Table body-->
			    </form>

			</table>
			<!--Table-->
			<?php } } ?>
		</div>
	</div>
		
	</div>
	

</div>





<?php include 'inc/slider.php' ; ?>
<?php include 'inc/footer.php' ; ?>