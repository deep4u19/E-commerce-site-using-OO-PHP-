<?php include 'inc/header.php';?>
<?php include 'inc/heading.php';?>
<?php include 'inc/navbar.php';?>


<!-- Main content starts -->
		<div class="container mainDiv">
			<div class="row" style="background: #f2f2f2">
				<div class="col-md-12 content-heading" style="background: #ccffcc;color: #333;">
				<h2 align="center" style="font-size: 38px;font-family: 'Bitter', serif;">Why choose Us??</h2>
				</div>

				<!-- Text contents -->
				<div class="col-md-8 chooseUs">
					

						<div>
							<h3 style="font-family: 'Bitter', serif;">We're safe!!!!</h3>
							<p>
								All of our partner pharmacies are held to first world country standards and are members of CIPA (the Canadian International Pharmacy Association.)
							</p>
						</div>
						<div>
							<h3 style="font-family: 'Bitter', serif;">Getting Your Rx To Us Is Easy!!!!!</h3>
							<p>
								We can receive prescriptions in a few different ways, we can transfer an active prescription from your local pharmacy, or contact your doctor for authorization on a new prescription. We also accept prescriptions by fax, email or upload via our website. However, we will require you to mail the original prescription in. We will need the original in order to process future refills.
							</p>
						</div>
						<div>
							<h3 style="font-family: 'Bitter', serif;">We're Cheap!!!!</h3>
							<p>
								Our drugs are developed for international markets, and prices internationally can be quite a bit cheaper than local prices. There are a few different factors our product pricing team takes into account when pricing and we are constantly updating and searching for the best values we can provide our customers!
							</p>
						</div>


<!-- Most popular items  -->
					

					
						<div class="popularItems">
							<h3 align="center" style="font-family: 'Bitter', serif;">Most popular Products</h3>
						
						

							<div class="row container-fluid">
							<?php  
							$getFpd=$pd->getFeaturedProduct();
							if($getFpd){
								while($result=$getFpd->fetch_assoc()){

								?>
								<div class="col-md-3 pop-pd">

									<div class="">
										<img class="img-thumbnail img-pop" src="admin/<?php echo $result['image'] ;?>">

										<div class="caption-custom">
					
											<p style="text-align: center;"><b><?php echo $result['productName'] ;?></b></p>
											<!-- <p><?php echo $fm->textShorten($result['body'],40) ;?></p> -->
											<a href="product.php?proid=<?php echo $result['productId']; ?>" class="btn btn-success center-block">Details</a>
										</div>
									</div>
								</div>
								<?php } } ?>

							</div>


						</div>
					
				</div>

<!-- Feedback contents -->




				<div class="col-md-4">

<!-- Icons -->
					<div class="row">

					
						<div class="col-md-6">	
							<img src="images/secure.png" class="img-responsive">
						</div>
						<div class="col-md-6">	
							<img src="images/7days.png" class="img-responsive"><br>
						</div>
					

					</div>



<!-- Feedbacks -->

					<div class="recent-feedback ">
						<div class="feedback-text">
							<h3 style="font-family: 'Bitter', serif;font-size: 22px;"><i class="fas fa-trophy" style="color: #ffcc00;"></i>Some recent feedbacks</h3><br>
						</div>

						<div class="rating">
							<p>
								<span style="color: #ffcc00">
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
								</span>-4 to 6 weeks for delivery is to long.4 to 6 weeks for delivery is to long.4 to 6 weeks for delivery is to long.
							</p>

							<p><b>--</b><i>Jack Han</i>,,Feb 5th, 2018</p>
						</div>

						<div class="rating">
							<p>
								<span style="color: #ffcc00">
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
								</span>-4 to 6 weeks for delivery is to long.4 to 6 weeks for delivery is to long.4 to 6 weeks for delivery is to long.
							</p>
							<p><b>--</b><i>Jack Han</i>,,Feb 5th, 2018</p>
						</div>

						<div class="rating">
							<p>
								<span style="color: #ffcc00">
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
								</span>-4 to 6 weeks for delivery is to long.4 to 6 weeks for delivery is to long.4 to 6 weeks for delivery is to long.
							</p>
							<p><b>--</b><i>Jack Han</i>,,Feb 5th, 2018</p>
						</div>

						<div class="rating">
							<div style="float: left;">					
							<p><i class="fas fa-pencil-alt"></i><a href="#">Write a review</a></p>
							</div>

						
					    	<div style="float: right;">
							<p><i class="fas fa-eye"></i><a href="#">See more reviews</a></p>
							</div>
							
						</div>

					</div>	
				</div>
			</div>
		</div>	<br>


<?php include 'inc/slider.php'; ?>
<?php include 'inc/footer.php'; ?>






		