<?php include 'inc/header.php' ; ?>
<?php include 'inc/navbar.php' ; ?>
<?php 
		$login=Session::get("cuslogin");
		if ($login==false) {
			echo "<script>window.location='login.php';</script>";
		}

 ?>
<?php 

 if(isset($_GET['delpro'])){
 	$delWishId=$_GET['delpro'];
 	$delWishId=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['delpro']);
 	$delProduct=$pd->delProductByCart($delWishId);
 	
 }

 ?>
<?php 
if(isset($_GET['delhis'])){
 	$delId=$_GET['delhis'];
 	$delId=preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['delhis']);
 	$delHistory=$pd->delHistory($delId);
 }




 ?>
<div class="container ">
	<div class="col-md-12 pro">
	
	<div class="row" align="center">
		<div class="col-md-5">
			<div class="col-md-12">
			<h3 class="">Your account informations</h3>

		<!--Table-->
		<?php 
		 $id=Session::get('cmrId');
		 $getData=$cmr->getCustomerData($id);
		 if($getData){
		 	while ($result=$getData->fetch_assoc()) {
		 		

		 ?>
		
			<table class="table table-striped tble">


			    <!--Table body-->
			    <tbody>
			        <tr>
			            <td width="10%">Name</td>
			            <td width="5%">:</td>
			            <td width="50%"><?php echo $result['name'] ;?></td>
			        </tr>
			        <tr>
			            <td width="10%">Address</td>
			            <td width="5%">:</td>
			            <td width="30%"><?php echo $result['address'] ;?></td>
			        </tr>
			        <tr>
			            <td width="10%">City</td>
			            <td width="5%">:</td>
			            <td width="30%"><?php echo $result['city'] ;?></td>
			        </tr>
			        <tr>
			            <td width="10%">Country</td>
			            <td width="5%">:</td>
			            <td width="30%"><?php echo $result['country'] ;?></td>
			        </tr>
			         <tr>
			            <td width="10%">Zip Code</td>
			            <td width="5%">:</td>
			            <td width="30%"><?php echo $result['zip'] ;?></td>
			        </tr>
			        <tr>
			            <td width="10%">Phone No</td>
			            <td width="5%">:</td>
			            <td width="30%"><?php echo $result['phone'] ;?></td>
			        </tr>
			        <tr>
			            <td width="10%">Email</td>
			            <td width="5%">:</td>
			            <td width="30%"><?php echo $result['email'] ;?></td>
			        </tr>
			        <tr>
			            <td width="10%"></td>
			            <td width="5%"></td>
			            <td width="30%"><a href="editProfile.php"><button class="btn btn-primary">Update Details</button></a></td>
			        </tr>
			    </tbody>
			    <!--Table body-->

			</table>
			<!--Table-->
			<?php } } ?>
		</div>

			<div class="col-md-12">
			<h3 class="">Your Wishlist</h3>
			<?php if(isset($delWishId)){
				echo $delWishId;
			} ?>
			<div class="main">
			    <div class="content1">
			    	<div class="cartoption">		
						<div class="cartpage payment-cartpage">
						    	
							<table class="tblone">
						
							<tr>
								<th width="5%">SL</th>
								<th width="45%">Medicine</th>
								
								<th width="45%">Chemical</th>
								<th width="5%">Action</th>
								
								
							</tr>
							<?php $getWishList=$pd->getAllWishList($id); 
								if($getWishList){
									$count=0;
									while ($result=$getWishList->fetch_assoc()) {
									$count++;	
									
						?>
							<tr>
								<td><?php echo $count ;?></td>
								<td><?php echo $result['medName'] ;?></td>
								<td><?php echo $result['chemName'] ;?></td>
								<td><a onclick="return confirm('ARE YOU SURE TO DELETE???')" href="?delpro=<?php echo $result['id'] ;?>">X</a></td>
							</tr>
							<?php } } ?>
							<?php if (isset($count)==0){
								echo "<span style='color:red;font-size:17px;'>**Wishlist Empty** </span>";
							} ?>
								
							
							
							
						</table>
						
					   
					</div>
					
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>


			</div>


		</div>

		<div class="col-md-7">
			<h3>Your Order History</h3>
			<div class="main">
			    <div class="content1">
			    	<div class="cartoption">		
						<div class="cartpage payment-cartpage">
						    	
							<table class="tblone">
							<tr>
								<th width="5%">SL</th>
								<th width="30%">Product</th>
								
								<th width="10%">Price</th>
								<th width="5%">Qty</th>
								<th width="10%">Total Price</th>
								<th width="30%">Date</th>
								<th width="5%">Status</th>
								<th width="5%">action</th>
								
							</tr>
							<?php 
								$cmrId=Session::get('cmrId');
								$getOrder=$ct->orderHistory($cmrId);
								if($getOrder){
									$i=0;
									$sum=0;
									while($result=$getOrder->fetch_assoc()){
										$i++;
							 ?>
							<tr>
								<td><?php echo($i)."." ;?></td>
								<td><?php echo $result['productName'] ;?></td>
								<td>$ <?php echo $result['price'] ;?></td>
								<td>				
										<?php echo($result['quantity']); ?>
										
								</td>
								<td>$<?php
										$total=$result['price']*$result['quantity'];
									 	echo (number_format("$total",2)) ;
									 ?>									 	
								</td>
								<td><?php echo $result['thisDate'] ;?></td>
								<td>Pending</td>
								<td><a onclick="return confirm('ARE YOU SURE TO DELETE???')" href="?delhis=<?php echo($result['id']); ?>">X</a></td>
								

							</tr>
								
							<?php } } ?>
							<?php if (isset($i)==0){
								echo "<span style='color:red;font-size:17px;'>**History Empty** </span>";
							} ?>
							
							
						</table>
						
					   
					</div>
					
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
		</div>
	</div>
		
	</div>
	

</div>





<?php include 'inc/slider.php' ; ?>
<?php include 'inc/footer.php' ; ?>