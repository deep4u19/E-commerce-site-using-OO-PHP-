$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip({title:"Your cart", placement: "bottom"});
	
		$(".loginText").popover({content:function(){
				return $('#pop-content').html();
			},
		 placement: "bottom",html:true,animation: true});


		$(".logoutText").popover({content:function(){
				return $('.pop-content-account').html();
			},
		 placement: "bottom",html:true,animation: true});



		// $('.a').hover(function() {
  //   	$('.b').css('color', '#fff');
  // 			}, function() {
  //   		// on mouseout, reset the background colour
  //   	$('.b').css('color', 'red');
 	// 		 });


});



function toggleIcon(e) {
    $(e.target)
        .prev('.panel-heading')
        .find(".more-less")
        .toggleClass('glyphicon-plus glyphicon-minus');
}
$('.panel-group').on('hidden.bs.collapse', toggleIcon);
$('.panel-group').on('shown.bs.collapse', toggleIcon);


// $(".loginText").popover({
//     html: true, placement:"bottom",
// 	content: function() {
//           return $('#popover-content').html();
//         }
// });


// back to top


$(document).ready(function() { 
var offset = 250;
var duration = 300;
$(window).scroll(function() {
if ($(this).scrollTop() > offset) {
$(".back-to-top").fadeIn(duration);
} else {
 $(".back-to-top").fadeOut(duration);
 }
 });
 
 $(".back-to-top").click(function(event) {
 event.preventDefault();
 
$("html, body").animate({scrollTop: 0}, duration);
 
return false;
 
})
 
});
 // 
