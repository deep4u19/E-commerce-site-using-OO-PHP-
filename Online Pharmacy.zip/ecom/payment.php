<?php include 'inc/header.php' ; ?>
<?php include 'inc/navbar.php' ; ?>
<?php 
		$login=Session::get("cuslogin");
		if ($login==false) {
			echo "<script>window.location='login.php';</script>";
		}

 ?>
 
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="col-md-12 mainPay">
				<div>
				<h3 style="font-size: 33px;font-family: 'Bitter', serif;">Choose your payment option</h3>
				<p>
				
				<a href="paymentoffline.php">Cash on delivery</a>
				<a href="404.php">Online Payment</a>
				</p>
				</div>
				<div class="backPage">
					<p><a href="cart.php">Previous page</a></p>
				</div>

				
			</div>
		</div>
	</div>  
</div>





<?php include 'inc/slider.php' ; ?>
<?php include 'inc/footer.php' ; ?>