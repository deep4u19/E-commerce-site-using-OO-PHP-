<?php 

		$filepath=realpath(dirname(__FILE__));

	  include ($filepath.'/../lib/session.php'); 
  	  include ($filepath.'/../lib/database.php');
	  include ($filepath.'/../helpers/format.php');
      Session::init();
      spl_autoload_register(function($class){
      include_once "classes/".$class.".php";
    });
	    $db=new Database();
	    $fm=new Format();
	    $pd=new Product();
	    $ct=new Cart();
	    $cat=new Category();
	    $cmr=new Customer();

?>
<?php if(isset($_POST['search'])){
	$searchChq=$_POST['search'];
	$searchChq=preg_replace("#[^0-9a-z]#i", "", $searchChq);
	$getSearch=$pd->getSearchResult($searchChq);

} ?>
			


<?php
  header("Cache-Control: no-cache, must-revalidate");
  header("Pragma: no-cache"); 
  header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 
  header("Cache-Control: max-age=2592000");
?>



<?php if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['login'])){
         		$cusLogin=$cmr->customerLogin($_POST);

         } ?>


<!DOCTYPE html>
<html>
<head>
	<title>Final project</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/search.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Berkshire+Swash|Courgette|Monoton|Kurale" rel="stylesheet">	
    <link rel="stylesheet" type="text/css" href="css/animate.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link href="https://fonts.googleapis.com/css?family=Karma|Lora|Muli|Roboto+Condensed|Righteous" rel="stylesheet">

    <!-- <link rel="icon" href="images\logo.png" sizes="32x32" type="image/png"> -->
	
</head>

<style>

	
</style>

<body>
	<div class="container-fluid wcRow">
		<div class="row ">

	<!--    *******************Wc text ********************           -->


			<div class="col-md-4 wcText pull-left">
				<a href="index.php" style="text-decoration: none;"><h1 style="color: #000;" class="animated pulse">your <span  style="color: #00cc00">Health</span>,,our <span style="color: #ff8c1a">Goal</span>..</h1></a>
			</div>



	<!--Search  -->
			<div class="col-md-4 " style="margin-top: 16px;">
			 <form id="searchthis" style="display:inline;" method="post" action="searchresult.php">
				<input required="required" id="namanyay-search-box" name="search" size="40" type="text" placeholder="Search Using Medicine or Drug Name"/>
				<input id="namanyay-search-btn" value="Go" type="submit"/>

				
				
			</form>

			</div>
			


	<!-- Cart   -->

			<div class="col-md-1 pull-right cart"  id="cart" >
					<label data-toggle="tooltip"><a href="cart.php" ><i style="color: #3b444b;" class="fas fa-medkit fa-3x cart-icon"></i></a><span class="badge cart-badge" style="background: orange;">
						<?php 
						$getData=$ct->checkCartTable();
						if($getData){

						$counter=$_SESSION['counter'];
						 //Its done using the tutorial
						// $counter=Session::get('counter');
					     echo $counter ;
					 	}else{
					 		echo "0";
					 	}

					     ?></span></label>
			</div>

	<!-- Login  -->



	<?php if (isset($_GET['cid'])){
				$delData=$ct->delCustomerCart();
         		Session::destroy();
         		

         } ?>

			<div class="col-md-3 login" id="asd" >
					<?php 
						$login=Session::get("cuslogin");
						if ($login==true) { ?>

						<h4 class="signupText logoutText" data-toggle='popover'  data-title=" Account"><a class="pointer"><i class="far fa-user fa-2x"></i>Account</a></h4>
							
						<?php } else{?>
						<h4 class="loginText signupText" data-toggle='popover'  data-title=" Log In"><a class="pointer"><i class="far fa-user fa-2x"></i>Login or Sign up</a></h4>

				    <?php }?>
			

					<div id="pop-content" class=" hide">
						<form class="pop-form" method="post">

							<div class="form-group">
								<input type="email" name="email" class="form-control" id="email" placeholder="Email Address">
								<input type="password" name="pass-login" class="form-control" id="pwd" class="Password" placeholder="Password">
							</div>

							<div class="checkbox">
							    <label><input type="checkbox"> Remember me</label>
							 </div>

							 <button class="btn btn-primary" name="login">
							 	Sign In
							 </button>

							 <a href="login.php" ><input type="button" value="New User??" name="" class="btn btn-success"  id="nUsr" >
							 	
							 </a><br>
							 <a class="forget pointer">Forgot Password??</a>

							
						</form>
						
					</div>


					<div id="pop-content" class="hide pop-content-account" >
						<div class="popover-content" style="width:138px;">
						
							<li class="liclas"><a href="profile.php"> <p>Profile</p></a></li>
							<li class="liclas"><a href="editProfile.php"> <p>Edit Details</p></a></li>
							<li style="list-style: none;"><a onclick="return confirm('ARE YOU SURE TO LOG OUT???')" href="?cid=<?php Session::get('cmrId');?>"><button class="btn btn-warning btn-logout">Logout</button></a></li>
						</div>
						
					</div>
			
			</div>



		</div>
	</div>