<?php
$to = "deep4u19@gmail.com";
$subject = "HTML email";

$message = "asdasdasdsadsaddasasd
";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


mail($to,$subject,$message,$headers);
?>