<?php 
	$filepath=realpath(dirname(__FILE__));
	include_once ($filepath.'/../lib/database.php');
	include_once ($filepath.'/../helpers/format.php');
?>

<?php 

class Brand{

	private $db;
	private $fm;
	
	public function __construct()
	{
		$this->db=new Database();
		$this->fm=new Format();

}
	public function brandInsert($brandName){
		$brandName=$this->fm->validation($brandName);
		$brandName=mysqli_real_escape_string($this->db->link,$brandName);
		if(empty($brandName)){
			$msg="<span style='font-size: 18px; color: red;'> Brand name field can't be empty </span>";
			return $msg;
		}else{
			$query="INSERT INTO brand_table(brandName) VALUES('$brandName')";
			$result=$this->db->insert($query);
			if($result){
				$msg="<span style='font-size: 18px; color: green;'> Brand name was added successfully </span>";
			return $msg;

			}else{
				$msg="<span style='font-size: 18px; color: red;'> Brand name was not added </span>";
			return $msg;
			}
		}
	}
	public function getAllBrand(){
		$query='SELECT * FROM brand_table ORDER BY brandId DESC';
		$result=$this->db->select($query);
		return $result;
	}

	public function getBrandById($id){
		$query="SELECT * FROM brand_table WHERE brandId='$id'";
		$result=$this->db->select($query);
		return $result;
	}

	public function brandUpdate($brandName,$id){
		$brandName=$this->fm->validation($brandName);
		$brandName=mysqli_real_escape_string($this->db->link,$brandName);
		$id       =mysqli_real_escape_string($this->db->link,$id);
		if(empty($brandName)){
			$msg="<span style='color:red;font-size:18px;'>Brand field can't be empty..</span>";
			return $msg;
		}else{
				$query="UPDATE brand_table SET brandName='$brandName' WHERE brandId='$id'";
				$result=$this->db->update($query);
				if($result){
					$msg="<span style='color:green; font-size:18px';>Brand name was updated successfully..</span>";
					return $msg;
				}else{
					$msg="<span style='color:red; font-size:18px';>Brand name was not updated..</span>";
					return $msg;

				}
		}
	}

	public function delBrandById($id){
		$query="DELETE FROM brand_table WHERE brandId='$id'";
		$result=$this->db->delete($query);
		if($result){
			$msg="<span style='color:green; font-size:18px';>Brand was deleted successfully..</span>";
				return $msg;
				}else{
					$msg="<span style='color:red; font-size:18px';>Brand was not deleted..</span>";
					return $msg;
				}
	}




}


?>