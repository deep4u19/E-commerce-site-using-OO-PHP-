<?php include 'inc/header.php' ; ?>
<?php include 'inc/navbar.php' ; ?>
<?php 
		$login=Session::get("cuslogin");
		if ($login==false) {
			// echo "<script>window.location='login.php';</script>";
		}

 ?>

<div class="container">
	<div class="row" align="center">
		<div class="col-md-12 animated pulse infinite">
			<h1 style="color: red;">Order Page</h1>
			
		</div>
		
	</div>
	

</div>





<?php include 'inc/slider.php' ; ?>
<?php include 'inc/footer.php' ; ?>