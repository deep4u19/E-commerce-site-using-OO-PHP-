<?php include 'inc/header.php' ; ?>
<?php include 'inc/navbar.php' ; ?>

<div class="container">
	<div class="row" style="    background: #f2f2f2;">
		<div class="col-md-12">
			<b><h1 align="center" style="font-size: 40px;font-family: 'Monoton', cursive;">Meet <span style="color: #00cc00;">The Goblins</span></h1></b>
			<div class="col-md-6 imageDiv pull-left">
				<img src="images/goblinsnew.jpg" class="img-responsive">		
			</div>
			<div class="col-md-6 articleDiv">
				<p >
					The goblins is a team founded by four friends with the common intention of developing web applications that must have beauty with brains.. All of them are currently the students of Shahjalal University Of Science And Technology who are appearing in the MS program in their respective departments and have intentions to move further regarding web development.. The cofounders of this team are :
				</p>
					<li><b>Deblina Bhowmick</b></li> 
					<li><b>Arman Hossain</b></li> 
					<li><b>Jannatul Ferdous Annie</b></li> 
					<li><b>Diponkor Sarker</b></li> <br>
				
				<p>

					For any quiries or suggestions you can contact the team from <a href="contact.php">Contact Us</a> or can directly mail at their business email address <b>teamthegoblins@gmail.com</b>..
				</p>
				
			</div>

		</div>
		
	</div>
	

</div>





<?php include 'inc/slider.php' ; ?>
<?php include 'inc/footer.php' ; ?>