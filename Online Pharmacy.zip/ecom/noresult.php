<?php include 'inc/header.php' ; ?>
<?php include 'inc/navbar.php' ; ?>

<div class="container" style="    background: #f2f2f2;">
	<div class="row" >
		<div class="col-md-12 ">
			<h1 align="center" class="animated pulse" style="color: red;">Sorry your query doesn't match with any of our products.. You can enter your query in the wishlist..</h1>
		</div>
	</div>

		
</div>
	






<?php include 'inc/slider.php' ; ?>
<?php include 'inc/footer.php' ; ?>