<?php include 'inc/header.php' ; ?>
<?php include 'inc/navbar.php' ; ?>
<?php 
	$login=Session::get("cuslogin");
		if ($login==false) {
			echo "<script>window.location='login.php';</script>";
		}
 ?>
<div class="container">
	<div class="row" align="center" style="background: #fff">
		<div class="col-md-12 center-block">
			<h1 class="animated pulse infinite" style="color: green;">Order Successfully Placed..</h1>
			<?php $cmrId=Session::get('cmrId');
				  $amount=$ct->payableAmount($cmrId);
				  
				  if($amount){ 	
				  	$sum=0;
				  	  while ($result=$amount->fetch_assoc()) {
				  		$price=$result['price'];
				  		$sum=$sum+$price;
					   	}

					}

				  			
			 ?>

			<p>Thanks for your order..</p>
			<p>Hopefully you will get the order soon.. 


			</p>
			<P>Check your order detais <a href="#">Here..</a></P>


			
					
		</div>
		
	</div>
	

</div>





<?php include 'inc/slider.php' ; ?>
<?php include 'inc/footer.php' ; ?>