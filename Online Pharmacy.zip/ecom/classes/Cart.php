<?php 
	$filepath=realpath(dirname(__FILE__));
	include_once ($filepath.'/../lib/database.php');
	include_once ($filepath.'/../helpers/format.php');
?>

<?php 


class Cart{
	private $db;
	private $fm;

	public function __construct(){
		$this->db=new Database();
		$this->fm=new Format();

	}

	public function addToCart($quantity,$id){
		$quantity=$this->fm->validation($quantity);
		$quantity=mysqli_real_escape_string($this->db->link,$quantity);
		$productId=mysqli_real_escape_string($this->db->link,$id);
		$sId=session_id();
		$squery="SELECT * FROM product_table WHERE productId='$productId' ";
		$result=$this->db->select($squery)->fetch_assoc();
		$productName=$result['productName'];
		$price=$result['price'];
		$image=$result['image'];
		$chquery="SELECT * FROM cart_table WHERE productId='$productId' AND sId='$sId' ";
		$getPro=$this->db->select($chquery);
		
		if($getPro){
			$msg="<span style='color: red; font-size:18px;'>***Product is already in the cart!!! Please view cart to update quantity***</span>";
			return $msg;
		}else{

		$query="INSERT INTO cart_table(sId,productId,productName,price,quantity,image) 
					VALUES('$sId','$productId','$productName','$price','$quantity','$image')";

				$result1=$this->db->insert($query);
				if($result1){
					echo "<script>window.location='cart.php';</script>";
				}else{
					echo "<script>window.location='404.php';</script>";
				}

			}
	}

	public function getCartProduct(){
		$sId=session_id();
		$query="SELECT * FROM cart_table WHERE sId='$sId'";
		$result=$this->db->select($query);
		return $result;
	}
	public function updateCartQuantity($cartId,$quantity){
		$cartId=$this->fm->validation($cartId);
		$cartId=mysqli_real_escape_string($this->db->link,$cartId);

		$quantity=$this->fm->validation($quantity);
		$quantity=mysqli_real_escape_string($this->db->link,$quantity);

		$query="UPDATE cart_table SET quantity='$quantity' WHERE cartId='$cartId' ";
			$updated_row=$this->db->update($query);
			if($updated_row){
				$msg="<span style='font-size: 18px; color: green;'> Quantity updated successfully !!   </span>";
				return $msg;
			}else{
				$msg="<span style='font-size: 18px; color: red;'> Quantity not updated !! </span>";
			return $msg;
			}

	}
	public function delProductByCart($delId){
		$delId=mysqli_real_escape_string($this->db->link,$delId);
		$query="DELETE FROM cart_table WHERE cartId='$delId'";
		$result=$this->db->delete($query);
		if($result){
			echo"<script>window.location='cart.php';</script>";
		}else{
			$msg="<span style='color:red;font-size:18px;'> Product Not deleted </span>";
			return $msg;
		}
	}
	public function checkCartTable(){
		$sId=session_id();
		$query="SELECT * FROM cart_table WHERE sId='$sId' ";
		$result=$this->db->select($query);
		return $result;

	}
	public function delCustomerCart(){
		$sId=session_id();
		$query="DELETE  FROM cart_table WHERE sId='$sId' ";
		$result=$this->db->delete($query);
	}


	public function orderProduct($cmrId){
		$sId=session_id();
		$query="SELECT * FROM cart_table WHERE sId='$sId' ";
		$getPro=$this->db->select($query);
		if($getPro){
			while ($result=$getPro->fetch_assoc()) {
				$productId=$result['productId'];
				$productName=$result['productName'];
				$quantity=$result['quantity'];
				$price=$result['price'];
				$image=$result['image'];
				

				$query_insert="INSERT INTO order_table(cmrId,productId,productName,quantity,price,image) 
					VALUES('$cmrId','$productId','$productName','$quantity','$price','$image')";

				$query_insert2="INSERT INTO history_table(cmrId,productId,productName,quantity,price,image) 
					VALUES('$cmrId','$productId','$productName','$quantity','$price','$image')";

				$inserted_row=$this->db->insert($query_insert);
				$inserted_row2=$this->db->insert($query_insert2);

			}
		}

	}
	public function orderHistory($cmrId){
		$query="SELECT * FROM history_table WHERE cmrId='$cmrId' ORDER BY id asc";
		$result=$this->db->select($query);
		return $result;
	}
	public function payableAmount($cmrId){
		$query="SELECT price FROM order_table WHERE cmrId='$cmrId' ";
		$result=$this->db->select($query);
		return $result;

	}
}

 ?>