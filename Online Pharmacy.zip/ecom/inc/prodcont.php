
<div class="container-fluid" style="width: 96%;
    background: #f2f2f2;">
	<?php 

	 $getPd1=$pd->getSingleProduct($id);
	 $getPd2=$getPd1->fetch_assoc();

	 Session::set("chem",$getPd2['chemical']); 
	 Session::set("prodId",$getPd2['productId']); ?>


<!-- Categories -->
<div class="row">

<div class="col-md-12">

			
				
	<div class="col-md-2 side-category">

		<p>
		All the categories 
		</p>
		<?php 
		$getCat=$cat->getAllCat();
		if($getCat){
		$i=0;
		while($result=$getCat->fetch_assoc()){

		?>
		<a href="#" style="font-size: 15px;"><i class="fas fa-caret-right" style="color: #333;font-size: 17px;margin-right: 2px;"></i>
		<?php echo $result['catName'] ;?>
		<span class="badge"><?php if($result['catId']=='8'){
			echo Session::get("proCount");
		}elseif($result['catId']=='9'){
			echo Session::get("NproCount");
		}else{
			echo Session::get("OCount");
		} ?></span>
		</a><hr>
		<?php } } ?>			
	</div>


<!-- Main contents -->
	<div class="col-md-7 main-category" >
		<?php $getPd=$pd->getSingleProduct($id); 
		if($getPd){
		while($result=$getPd->fetch_assoc()){?>

		<div class="location">
			<h4><p><a href="index.php" style="color: #000;">Home</a>/<a href="category.php" style="color: #000;"> 
			<?php echo($result['catName']) ;?></a>
			/<a href="#" style="color: #fff;"> <?php echo($result['productName']) ;?></a>

			</p></h4>
		</div>




		<div class="col-md-12 main-content">


			<div class="col-md-4 pull-left product-img">
				<img src="admin/<?php echo $result['image']; ?>" class="img-pop1"><br>

			</div>

			<div class="col-md-8 pull-right cart-sec">
				<h2><?php echo $result['productName']; ?></h2>
				<p><?php echo $result['body']; ?></p>
				<p><b><span  class="text-danger">
				<?php if($result['catName']=='Prescribed Drugs'){ ?>!!Prescription required!! &nbsp &nbsp &nbsp</span> 
				<?php }elseif($result['catName']=='Non Prescribed Drugs'||$result['catName']=='Others'){ ?>

				!!Prescription not required!! <?php } ?>
				<span style="color: green;">In stock</span></b></p>

				<div class="price">
					<p>Price: &nbsp <span>$<?php echo $result['price']; ?> (**Per Strip/Box/Bottle**)</span></p>
					<!-- <p>Category: <span><?php echo $result['catName']; ?></span></p> -->
					<p>Chemical:&nbsp <span><?php echo $result['chemical']; ?></span></p>
					<p>Brand:&nbsp <span><?php echo $result['brandName']; ?></span></p>
				</div>
				<p><?php if(isset($addCart)){
					echo "<br>".$addCart;
					} ?></p>
				<div class="add-cart">
					<form action="" method="post">
					<input type="number" class="buyfield" name="quantity" value="1"/>
					<input type="submit" class="btn btn-success cart-btn" name="submit" value="Buy Now"/>
					<p>
					<?php if($result['medType']=='0'){ ?>
					<h4>**Note: Each strip/ box/ bottle consists of <?php echo($result['tabletCount']) ;?> tablets..</h4>
					<?php }elseif ($result['medType']=='1') {?>
						<h4>**Note: Each strip/ box/ bottle consists of <?php echo($result['tabletCount']) ;?> tablets..</h4>
					<?php }elseif ($result['medType']=='2') { ?>
						<h4>**Note: Each bottle consists of <?php echo($result['tabletCount']) ;?> mL serum..</h4>
					<?php }else{?>
						<h4>**Note: This Is different types <?php echo($result['tabletCount']) ;?> of drugs</h4>

					<?php  } ?>
					</p>
					</form>				
				</div>
			</div>


			<!-- Description sec -->




		</div>


<!-- About the product -->
		<div class="col-md-12">

			<h1>About the product</h1><br>
			<ul class="nav nav-tabs">
			<li class="active"><a href="#tab1" data-toggle="tab">Product Information</a></li>
			<!-- <li><a href="#tab2" data-toggle="tab">Image Gallery</a></li> -->
			<li><a href="#tab2" data-toggle="tab">Wikipedia Info</a></li>

			</ul>

			<!-- Tab section -->
			<div class="tab-content">
				<div class="tab-pane active" id="tab1">
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-12">

								<div class="demo">				

									<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

										<div class="panel panel-default">
											<div class="panel-heading" role="tab" id="headingOne">
											<h4 class="panel-title">
											<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"
											aria-expanded="true" aria-controls="collapseOne">
											<i class="more-less glyphicon glyphicon-plus"></i>
											Usage infos
											</a>
											</h4>
											</div>
											<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
											<div class="panel-body">
											<!-- Tabs navigation -->
											<ul class="nav nav-tabs">
											<li class="active"><a href="#tabb1" data-toggle="tab">IMPORTANT</a></li>
											<li><a href="#tabb2" data-toggle="tab">WARNING</a></li>
											<!-- <li><a href="#tabb3" data-toggle="tab">USES</a></li>
											<li><a href="#tabb4" data-toggle="tab">OTHER USES</a></li> -->
											<li><a href="#tabb3" data-toggle="tab">HOW TO USE</a></li>
											<li><a href="#tabb4" data-toggle="tab">PRECAUTIONS</a></li>



											</ul>

											<!-- Tab section -->
											<div class="tab-content">
											<div class="tab-pane active" id="tabb1">
											<div class="container-fluid">
											<div class="row">
											<div class="col-md-12">
											<h2>HOW TO USE THIS INFORMATION:</h2>
											<p><?php echo $result['important'] ;?>

											</p>

											</div>

											</div>
											</div>
											</div>



											<div class="tab-pane" id="tabb2">
											<div class="container-fluid">
											<div class="row">
											<div class="col-md-12"><br>
											<p> <?php echo $result['warning'] ;?></p>
											</div>

											</div>
											</div>
											</div>




											<div class="tab-pane" id="tabb3">
											<div class="container-fluid">
											<div class="row">
											<div class="col-md-12"><br>
											<p><?php echo $result['howUse'] ;?></p>
											</div>

											</div>
											</div>
											</div>



											<div class="tab-pane" id="tabb4">
											<div class="container-fluid">
											<div class="row">
											<div class="col-md-12"><br>
											<p><?php echo $result['precaution'] ;?></p>
											</div>

											</div>
											</div>
											</div>

											</div>





											</div>
											</div>
											</div>
											<div class="panel panel-default">
											<div class="panel-heading" role="tab" id="headingTwo">
											<h4 class="panel-title">
											<a role="button" data-toggle="collapse" data-parent="#accordion" 
											href="#collapseTwo" 
											aria-expanded="true" aria-controls="collapseTwo">
											<i class="more-less glyphicon glyphicon-plus"></i>
											What is <?php echo $result['productName'] ;?> Used For
											</a>
											</h4>
											</div>
											<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" 
											aria-labelledby="headingTwo">
											<div class="panel-body">
											<p><?php echo $result['uses'] ;?></p>
											</div>
											</div>
											</div>

											<div class="panel panel-default">
											<div class="panel-heading" role="tab" id="headingThree">
											<h4 class="panel-title">
											<a class="collapsed" role="button" data-toggle="collapse" 
											data-parent="#accordion" 
											href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
											<i class="more-less glyphicon glyphicon-plus"></i>
											<?php echo $result['productName'] ;?> Side Effects 
											</a>
											</h4>
											</div>
											<div id="collapseThree" class="panel-collapse collapse" role="tabpanel" 
											aria-labelledby="headingThree">
											<div class="panel-body">
											<p><?php echo $result['sEffect'] ;?></p>

											</div>
											</div>
											</div>
											</div>


											</div><!-- panel-group -->








							</div>
						</div>

					</div>
				</div>

				<div class="tab-pane" id="tab2">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<p>Wikipedia is an online open-content collaborative encyclopedia, 
							that is, a voluntary association of individuals and groups working 
							to develop a common resource of human knowledge. The structure of the project
							allows anyone with an Internet connection to alter its content.</p>

							<!-- <iframe src="#"  height="400" class="embed-wiki"> -->
							<iframe src="<?php echo $result['wiki'] ;?>"  width="100%"  
							height="400" class="embed-wiki">
							<p>Your browser does not support iframes.</p>
							</iframe>
							<!-- https://en.m.wikipedia.org/wiki/Sertraline -->
						</div>
					</div>
				</div>
			</div>


			</div>



			


		</div>


	</div>

		<?php } } ?>

<!-- Related Product -->


		<div class="col-md-2 related-product">
			<div class="col-md-12 rp-head">
				<h4><p>Similar products</p></h4>
			</div>

		
			<?php 
			$chem=Session::get("chem");
			$prodId=Session::get("prodId");
			$relatedPd=$pd->getRelatedProduct($chem,$prodId);
			if($relatedPd){
				while ($result=$relatedPd->fetch_assoc()) {
			?>
			<div class="col-md-12">

				<!-- <div class="thumbnail"> -->
				<div class="">
				<a href="product.php?proid=<?php echo $result['productId']; ?>"><img style="height: 165px; width:165px;" class="img-rounded" src="admin/<?php echo $result['image']; ?>"></a>


				</div>
				<div class="caption">
				

				<a href="product.php?proid=<?php echo $result['productId']; ?>"><p><?php echo $result['productName'] ;?></p></a><hr>
				
				</div>


			</div>

			<?php } }else{
				echo "<p>No other product found for this chemical name..</p>";
			} ?>

			



		</div>
</div>


</div>


<!-- Related products -->




</div>	
</div>
