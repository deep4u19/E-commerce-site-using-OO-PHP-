 		<div class="navbar navbar-default  navbar-default">
			<div class="container-fluid">
				<div class="navbar-header">
					<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>

				</div>

				<div class="navbar-collapse collapse " id="navbarPos">
					<ul class="nav navbar-nav">
						<li><a class="nav-hover" href="index.php" style="font-size: 19px;margin-left: 45px;"><i class="fas fa-home"></i>Home</a></li>
						<li class="dropdown ">
							<a class="nav-hover-n" href="#" class="dropdown-toggle" data-toggle="dropdown" style="font-size: 19px;">Drugs<b class="caret"></b></a>
							<div class="dropdown-menu mega-menu">
								<div class="row" >
			<!-- 					<div class="col-lg-4">
										<img src="css/healthylife.jpg" class="img-responsive">
										
										<p>Get all the required drugs here..</p>
										
									</div> -->
<!-- Presribed -->
									<div class="col-md-3 col-md-offset-1" style="border-right: 1px solid;">
										
										<p style="border-bottom: 1px dashed;" class="megaHeading"><b>Presribed </b></p>
										
										<?php  
										$getPresProduct=$pd->getPrescribedProduct();
										if($getPresProduct){
											while($result=$getPresProduct->fetch_assoc()){

											?>
										<a href="product.php?proid=<?php echo $result['productId']; ?>"><p><i class="fas fa-plus " style="margin-right: 5px; color: red;"></i><?php echo $result['productName'];?></p></a>
									
										<?php } } ?>
										<a href="category.php"><p><i style="color: #00b300;margin-right: 5px;" class="fas fa-angle-double-right"></i>View all</p></a>
											

									</div>
<!-- Non Presribed -->
									<div class="col-md-4" style="border-right: 1px solid;">
										<p style="border-bottom: 1px dashed;" class="megaHeading"><b>Non Presribed</b></p>
										<?php  
										$getNPresProduct=$pd->getNonPrescribedProduct();
										if($getNPresProduct){
											while($result=$getNPresProduct->fetch_assoc()){

											?>
										<a href="product.php?proid=<?php echo $result['productId']; ?>"><p><i class="fas fa-plus " style="margin-right: 5px; color: red;"></i><?php echo $result['productName'];?></p></a>
									
										<?php } } ?>
										<a href="category.php"><p><i style="color: #00b300;margin-right: 5px;" class="fas fa-angle-double-right "></i>View all</p></a>
										
									</div>
<!-- Others -->
									<div class="col-md-3" >
										<p style="border-bottom: 1px dashed;" class="megaHeading"><b >Others</b></p>
										<?php  
										$getOtherProduct=$pd->getOtherProduct();
										if($getOtherProduct){
											while($result=$getOtherProduct->fetch_assoc()){

											?>
										<a href="product.php?proid=<?php echo $result['productId']; ?>"><p><i class="fas fa-plus " style="margin-right: 5px; color: red;"></i><?php echo $result['productName'];?></p></a>
									
										<?php } } ?>
										<a href="category.php"><p><i style="color: #00b300;margin-right: 5px;" class="fas fa-angle-double-right"></i >View all</p></a>										
									</div>
									<div class="col-md-12 "><a href="category.php" class="upload-pres pull-left"><h4 style=""><i style="margin-right: 5px;" class=" fas fa-spinner fa-spin"></i>Upload prescription</h4></a>

										<a href="category.php" class="upload-wish pull-right"><h4 style=""><i class="far fa-check-square" style="margin-right: 5px;"></i>Your Wishlist</h4></a>

									</div>
								</div>
								
							</div>
						</li>
						
						
						<li>
							<a class="nav-hover" href="#" class="dropdown-toggle" data-toggle="dropdown" style="font-size: 19px;">Services <b class="caret"></b></a>
							<ul class="dropdown-menu dropdown-class">
								<li><a href="#">Call Ambulence</a></li>
								<li><a href="#">Set appointment</a></li>
								<li><a href="#">Your needs</a></li>
								
							</ul>
						</li>

						<li>
							<a class="nav-hover" href="#" class="dropdown-toggle" data-toggle="dropdown" style="font-size: 19px;">Pets<b class="caret"></b></a>
							<ul class="dropdown-menu dropdown-class">
								<li><a href="#">Pet foods</a></li>
								<li><a href="#">Pet vaccines</a></li>
								<li><a href="#">Pet hospitals</a></li>
								
							</ul>
						</li>
						<li><a class="nav-hover" href="aboutus.php" style="font-size: 19px;">About Us</a></li>
						<li><a class="nav-hover" href="contact.php" style="font-size: 19px;">Contact Us</a></li>
					</ul>

					
 					
 					
 							
 				</div>

 			</div>

 		</div>