<?php 
	$filepath=realpath(dirname(__FILE__));
	include_once ($filepath.'/../lib/database.php');
	include_once ($filepath.'/../helpers/format.php');
?>

<?php 


class Customer{
	private $db;
	private $fm;

	public function __construct(){
		$this->db=new Database();
		$this->fm=new Format();

	}

	public function customerRegistration($data){
		$name=mysqli_real_escape_string($this->db->link,$data['name']);
		$address=mysqli_real_escape_string($this->db->link,$data['address']);
		$city=mysqli_real_escape_string($this->db->link,$data['city']);
		$country=mysqli_real_escape_string($this->db->link,$data['country']);
		$zip=mysqli_real_escape_string($this->db->link,$data['zip']);
		$phone=mysqli_real_escape_string($this->db->link,$data['phone']);
		$email=mysqli_real_escape_string($this->db->link,$data['email']);
		$pass=mysqli_real_escape_string($this->db->link, $data['pass-signup']);
		if($name==""|| $address==""|| $city==""|| $country==""|| $zip==""|| $phone==""|| $email==""|| $pass==""){
			$msg="<span style='color:red; font-size:18px;'>NO FIELD CAN BE EMPTY !!!</span>";
			return $msg;
		}

			$mailQuery="SELECT * FROM customer_table WHERE email='$email' LIMIT 1 ";
			$mailChk=$this->db->select($mailQuery);

			if($mailChk !=false){
				$msg="<span style='color:red; font-size:18px;'>Email already exists !!!</span>";
				return $msg;
					}else{
						$query="INSERT INTO customer_table(name,address,city,country,zip,phone,email,pass) 
					VALUES('$name','$address','$city','$country','$zip','$phone','$email','$pass')";

				$result=$this->db->insert($query);
				if($result){
					$msg="<span style='font-size: 18px; color: green;'>Customer data inserted successfully</span>";
					return $msg;

				}else{
					$msg="<span style='font-size: 18px; color: red;'>Customer data wasn't inserted ..</span>";
					return $msg;
				}
					}
		
	
		}
	public function customerLogin($data){
		$email=mysqli_real_escape_string($this->db->link,$data['email']);
		$pass=mysqli_real_escape_string($this->db->link, $data['pass-login']);
		if ($email==''||$pass=='') {
			$msg="<span style='font-size: 18px; color: red;'>No field can be empty..</span>";
					return $msg;
		}


			$query="SELECT * FROM customer_table WHERE email='$email' AND pass='$pass' ";
			$result=$this->db->select($query);
			if ($result !=false) {
			$value=$result->fetch_assoc();
			Session::set("cuslogin",true);
			Session::set("cmrId",$value['id']);
			Session::set("cmrName",$value['name']);
			header('Location: '.$_SERVER['PHP_SELF']);
			
  			die;
		}else{
			$msg="<span style='font-size: 15px; color: red;'>Email or Password didn't match..</span>";
			return $msg;
		}

	}
	public function getCustomerData($id){
		$query="SELECT * FROM customer_table WHERE id='$id' ";
		$result=$this->db->select($query);
		return $result;
	}
	public function customerUpdate($data,$cmrId){
		$name=mysqli_real_escape_string($this->db->link,$data['name']);
		$address=mysqli_real_escape_string($this->db->link,$data['address']);
		$city=mysqli_real_escape_string($this->db->link,$data['city']);
		$country=mysqli_real_escape_string($this->db->link,$data['country']);
		$zip=mysqli_real_escape_string($this->db->link,$data['zip']);
		$phone=mysqli_real_escape_string($this->db->link,$data['phone']);
				if($name==""|| $address==""|| $city==""|| $country==""|| $zip==""|| $phone==""){
			$msg="<span style='color:red; font-size:18px;'>NO FIELD CAN BE EMPTY !!!</span>";
			return $msg;
		}else{
				$query="UPDATE customer_table 
				SET 
				name='$name',
				address='$address',
				city='$city',
				country='$country',
				zip='$zip',
				phone='$phone'
				WHERE id='$cmrId';";

				$updated_row=$this->db->update($query);
				if($updated_row){
					$msg="<span style='font-size: 18px; color: green;'> Customer's detais updated successfully   </span>";
					return $msg;
				}else{
					$msg="<span style='font-size: 18px; color: red;'> Customer's detais wasn't updated</span>";
				return $msg;
				}
					}

	}
	
}
 ?>